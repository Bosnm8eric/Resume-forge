# Resume Forge Frontend (Simple 1-page)

This is a minimal React + Vite frontend for Resume Forge. Upload this directory to Render as a Static Site or to Vercel.

## Setup
1. Edit `package.json` if needed and run `npm install`.
2. Set environment variable `VITE_API_BASE` in your hosting platform to your backend URL (e.g. https://resume-forge-api.onrender.com)
3. Build: `npm run build` and deploy the `dist/` folder if hosting manually.

## Mobile deployment on Render
- Choose Static Site -> Upload repo/zip -> Set `VITE_API_BASE` env var -> Deploy

