import React, { useState, useEffect } from 'react';

const API_BASE = import.meta.env.VITE_API_BASE || 'https://your-backend.example.com';

export default function App() {
  const [step, setStep] = useState('form');
  const [plan, setPlan] = useState('basic');
  const [form, setForm] = useState({ name: '', email: '', experience: '', education: '', targetJob: '', extras: '' });
  const [error, setError] = useState(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const sid = params.get('session_id');
    if (sid) {
      setStep('processing');
      pollStatus(sid);
    }
  }, []);

  async function pollStatus(sessionId) {
    try {
      const res = await fetch(`${API_BASE}/api/checkout-session-status?session_id=${encodeURIComponent(sessionId)}`);
      const json = await res.json();
      if (json.status === 'ready') {
        setStep('success');
        window.sessionStorage.setItem('downloadUrl', json.downloadUrl);
        return;
      }
      if (json.status === 'failed') {
        setError('Resume generation failed. Please contact support.');
        setStep('form');
        return;
      }
    } catch (e) {
      console.error(e);
    }
    setTimeout(() => pollStatus(sessionId), 3000);
  }

  function updateField(k, v) { setForm(s => ({ ...s, [k]: v })); }

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    if (!form.name || !form.email) {
      setError('Please provide name and email');
      return;
    }
    setStep('redirecting');
    try {
      const res = await fetch(`${API_BASE}/api/create-checkout-session`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plan, userData: form })
      });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        setError('Failed to create checkout session');
        setStep('form');
      }
    } catch (err) {
      console.error(err);
      setError('Failed to contact server');
      setStep('form');
    }
  }

  return (
    <div className="container">
      <header><h1>Resume Forge</h1><p>AI-powered resumes — fast & automated</p></header>
      {step === 'form' && (
        <form onSubmit={handleSubmit} className="card">
          <label>Full name<input value={form.name} onChange={e=>updateField('name', e.target.value)} /></label>
          <label>Email<input value={form.email} onChange={e=>updateField('email', e.target.value)} /></label>
          <label>Target job<input value={form.targetJob} onChange={e=>updateField('targetJob', e.target.value)} /></label>
          <label>Experience<textarea value={form.experience} onChange={e=>updateField('experience', e.target.value)} /></label>
          <label>Education<input value={form.education} onChange={e=>updateField('education', e.target.value)} /></label>
          <label>Extras<input value={form.extras} onChange={e=>updateField('extras', e.target.value)} /></label>
          <div className="plans">
            <label><input type="radio" name="plan" checked={plan==='basic'} onChange={()=>setPlan('basic')} /> Basic - $14.99</label>
            <label><input type="radio" name="plan" checked={plan==='premium'} onChange={()=>setPlan('premium')} /> Premium - $29.99</label>
            <label><input type="radio" name="plan" checked={plan==='pro'} onChange={()=>setPlan('pro')} /> Pro - $49.99</label>
          </div>
          {error && <div className="error">{error}</div>}
          <button className="btn" type="submit">Generate Resume</button>
        </form>
      )}

      {step === 'redirecting' && <div className="card"><p>Redirecting to secure checkout...</p></div>}
      {step === 'processing' && <div className="card"><p>Payment received — generating your resume. This may take up to a minute.</p></div>}
      {step === 'success' && (
        <div className="card">
          <h2>Your resume is ready</h2>
          <a className="btn" href={window.sessionStorage.getItem('downloadUrl')||'#'}>Download Resume</a>
          <p>We also emailed a copy to you.</p>
        </div>
      )}
      <footer>© {new Date().getFullYear()} Resume Forge</footer>
    </div>
  );
}
