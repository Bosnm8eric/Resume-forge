# Resume Forge Backend (Ready-to-deploy ZIP)

This archive contains a single-file Express backend for Resume Forge, configured to use **gpt-4-turbo** and **Brevo (Sendinblue) SMTP** by default.

## Files included
- `server.js` — main Express server (Stripe webhook, OpenAI integration, PDF creation, email sending)
- `package.json`
- `.env.example`
- `resumes/` directory (created at runtime to store generated PDFs)

## How to deploy from your phone (Render/Railway/Vercel or Replit)

1. Upload the ZIP to Render or Railway (both support repo uploads or connecting GitHub).
2. Add environment variables from `.env.example` to your provider's dashboard (replace keys with real values).
   - STRIPE_SECRET_KEY
   - STRIPE_WEBHOOK_SECRET (important for webhook signature verification)
   - OPENAI_API_KEY
   - SMTP_HOST (smtp-relay.sendinblue.com)
   - SMTP_PORT (587)
   - SMTP_USER (from Brevo)
   - SMTP_PASS (from Brevo)
   - SMTP_FROM (optional)
   - BASE_URL (e.g. https://yourdomain.com)
3. Ensure your Stripe webhook endpoint is set to `https://<your-backend>/api/webhook` and the webhook secret is placed in `STRIPE_WEBHOOK_SECRET`.
4. Start the service. The server runs `server.js` and will serve `/resumes/<sessionId>.pdf` for downloads.
5. Connect your frontend (use the React frontend previously created) and point the create-checkout-session POST to your deployed backend.
6. Test a purchase using Stripe test cards. After a successful test payment, Stripe will trigger the webhook and the resume should be generated and emailed.

## Notes & Tips
- This is an MVP single-file implementation intended to be easy to deploy. For production, consider:
  - Using a persistent DB (Postgres / SQLite) instead of in-memory session store
  - Protecting the `/resumes` files with signed URLs or temporary tokens
  - Adding rate limits and request validation
  - Monitoring and logging, backups
- Cost considerations: OpenAI usage and Stripe fees are the main variable costs. Brevo has free tiers for SMTP usage but check limits.

## Support
If you want, I can also:
- Convert this to a Git repo and push to GitHub
- Create a Render or Railway deployment guide with screenshots for phone use
- Add a persistent SQLite store and simple analytics
