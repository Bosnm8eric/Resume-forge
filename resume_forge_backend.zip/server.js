import express from 'express';
import Stripe from 'stripe';
import bodyParser from 'body-parser';
import fs from 'fs';
import path from 'path';
import PDFDocument from 'pdfkit';
import nodemailer from 'nodemailer';
import cors from 'cors';
import dotenv from 'dotenv';
import OpenAI from 'openai';

dotenv.config();

const PORT = process.env.PORT || 3000;
const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY;
const STRIPE_WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const SMTP_HOST = process.env.SMTP_HOST;
const SMTP_PORT = process.env.SMTP_PORT || 587;
const SMTP_USER = process.env.SMTP_USER;
const SMTP_PASS = process.env.SMTP_PASS;
const SMTP_FROM = process.env.SMTP_FROM || `\"Resume Forge\" <${SMTP_USER}>`;
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;

if (!STRIPE_SECRET_KEY || !OPENAI_API_KEY || !SMTP_USER || !SMTP_PASS || !STRIPE_WEBHOOK_SECRET) {
  console.warn('Warning: Missing one or more required environment variables. See .env.example for required keys.');
}

const stripe = new Stripe(STRIPE_SECRET_KEY, { apiVersion: '2023-08-16' });
const openai = new OpenAI({ apiKey: OPENAI_API_KEY });

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Make sure resumes directory exists
const RESUMES_DIR = path.join(process.cwd(), 'resumes');
if (!fs.existsSync(RESUMES_DIR)) fs.mkdirSync(RESUMES_DIR);

// Serve generated PDF files statically
app.use('/resumes', express.static(RESUMES_DIR));

// In-memory session status store (MVP). Use a DB in production.
const sessionsStatus = {}; // sessionId -> { status, downloadUrl?, email?, error? }

// Utility: generate resume text using OpenAI
async function generateResumeText(userData) {
  const prompt = `You are an expert resume writer. Produce a concise, ATS-friendly resume in plain text.
Name: ${userData.name || 'Name Not Provided'}
Target job: ${userData.targetJob || 'Not specified'}
Experience (raw):
${userData.experience || 'Not provided'}

Education: ${userData.education || 'Not provided'}

Tone/Notes: ${userData.extras || 'Professional, concise'}

Output format:
- Start with name and contact line
- Summary (2-3 lines)
- Professional Experience (bullet points)
- Education
- Skills (extract keywords)

Write the resume. Do not include JSON or any commentary. Use bullet points and short sentences.`;

  const resp = await openai.chat.completions.create({
    model: 'gpt-4-turbo',
    messages: [{ role: 'user', content: prompt }],
    max_tokens: 1200,
  });

  const text = resp.choices && resp.choices[0] && resp.choices[0].message && resp.choices[0].message.content;
  if (!text) throw new Error('OpenAI returned no content');
  return text;
}

// Utility: create a PDF from text using pdfkit
function createResumePDF(text, filename) {
  return new Promise((resolve, reject) => {
    const filePath = path.join(RESUMES_DIR, filename);
    const doc = new PDFDocument({ margin: 50 });
    const stream = fs.createWriteStream(filePath);
    doc.pipe(stream);

    const lines = text.split('\n').filter(Boolean);
    if (lines.length > 0) {
      doc.fontSize(18).text(lines[0], { continued: false });
      doc.moveDown(0.5);
      doc.fontSize(10).text(lines.slice(1).join('\n'));
    } else {
      doc.fontSize(10).text(text);
    }

    doc.end();
    stream.on('finish', () => resolve(filePath));
    stream.on('error', (err) => reject(err));
  });
}

// Utility: send email with attachment using SMTP
async function sendResumeEmail(to, filePath) {
  const transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: Number(SMTP_PORT),
    secure: Number(SMTP_PORT) === 465, // true for 465, false for other ports
    auth: { user: SMTP_USER, pass: SMTP_PASS },
  });

  const info = await transporter.sendMail({
    from: SMTP_FROM,
    to,
    subject: 'Your Resume Forge resume is ready',
    text: 'Thanks for using Resume Forge. Your resume is attached. Reply to this email if you have any issues.',
    attachments: [{ filename: path.basename(filePath), path: filePath }],
  });

  return info;
}

// POST /api/create-checkout-session
app.post('/api/create-checkout-session', async (req, res) => {
  try {
    const { plan, userData } = req.body;
    if (!userData || !userData.email) return res.status(400).json({ error: 'userData with email required' });

    const planAmounts = { basic: 1499, premium: 2999, pro: 4999 };
    const amount = planAmounts[plan] || planAmounts.basic;

    const metadata = { userData: JSON.stringify(userData) };

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      line_items: [{
        price_data: {
          currency: 'usd',
          product_data: { name: `Resume Forge (${plan || 'basic'})` },
          unit_amount: amount
        },
        quantity: 1
      }],
      metadata,
      success_url: `${BASE_URL}/?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${BASE_URL}/cancel`
    });

    sessionsStatus[session.id] = { status: 'pending', email: userData.email };
    res.json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// Stripe webhook endpoint (raw body required)
app.post('/api/webhook', bodyParser.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature verification failed.', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const sessionId = session.id;
    sessionsStatus[sessionId] = { status: 'processing', email: session.customer_details && session.customer_details.email };

    let userData = {};
    try {
      if (session.metadata && session.metadata.userData) userData = JSON.parse(session.metadata.userData);
    } catch (e) {
      console.warn('Failed to parse userData from metadata', e);
    }
    if (!userData.email && session.customer_details && session.customer_details.email) userData.email = session.customer_details.email;

    (async () => {
      try {
        const text = await generateResumeText(userData);
        const filename = `${sessionId}.pdf`;
        const filePath = await createResumePDF(text, filename);

        if (userData.email) {
          await sendResumeEmail(userData.email, filePath);
        }

        const downloadUrl = `${BASE_URL.replace(/\\/$/, '')}/resumes/${encodeURIComponent(filename)}`;
        sessionsStatus[sessionId] = { status: 'ready', downloadUrl, email: userData.email };
        console.log(`Resume generated and emailed for session ${sessionId}`);
      } catch (err) {
        console.error('Error during resume generation pipeline', err);
        sessionsStatus[sessionId] = { status: 'failed', error: String(err) };
      }
    })();
  }

  res.json({ received: true });
});

// GET /api/checkout-session-status?session_id=...
app.get('/api/checkout-session-status', (req, res) => {
  const sessionId = req.query.session_id;
  if (!sessionId) return res.status(400).json({ error: 'session_id required' });
  const s = sessionsStatus[sessionId];
  if (!s) return res.json({ status: 'unknown' });
  res.json(s);
});

app.get('/', (req, res) => res.send('Resume Forge backend is running.'));

app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
